﻿namespace $safeprojectname$.Constants
{
    public static class Roles
    {
        public const string Seller = "Seller";
        public const string Customer = "Customer";
    }
}
