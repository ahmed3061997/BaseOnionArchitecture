﻿namespace $safeprojectname$.Constants
{
    public static class Cookies
    {
        public const string RefreshToken = "refresh-token";
    }
}
