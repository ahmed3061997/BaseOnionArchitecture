﻿using System.Text.Json.Serialization;

namespace $safeprojectname$.Models.Authentication
{
    public class JwtToken
    {
        public string Token { get; set; }
        [JsonIgnore]
        public string RefreshToken { get; set; }
        [JsonIgnore]
        public DateTime RefreshTokenExpiresOn { get; set; }
    }
}
