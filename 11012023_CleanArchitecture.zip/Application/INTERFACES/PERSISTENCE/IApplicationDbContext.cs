﻿using Microsoft.EntityFrameworkCore;

namespace $safeprojectname$.Interfaces.Persistence
{
    public interface IApplicationDbContext
    {
        DbSet<T> Set<T>() where T : class;
        Task<int> SaveChangesAsync();
    }
}
