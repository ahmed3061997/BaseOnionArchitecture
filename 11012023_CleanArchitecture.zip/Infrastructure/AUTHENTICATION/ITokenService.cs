﻿using $ext_projectname$.Application.Models.Authentication;

namespace $safeprojectname$.Authentication
{
    public interface ITokenService
    {
        Task<JwtToken> GenerateToken(ApplicationUser user);
        Task<JwtToken> RefreshToken(string token);
    }
}
